<div id="tb-blog-metabox" class='tb_metabox'>
	<?php
	$this->textarea('post_quote',
			'Content',
			esc_html__('Please type the text for your quote here.','ruya')
	);
	?>
</div>
