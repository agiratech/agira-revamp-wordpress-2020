<?php
/* Add extra type on visual composer */
require_once RUYA_INCLUDES.'types/ruya_template.php';
require_once RUYA_INCLUDES.'types/ruya_template_img.php';